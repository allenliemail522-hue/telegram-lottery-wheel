# Telegram Lottery Wheel
简单静态转盘抽奖页面，抽中后会跳转到 Telegram 与工作人员联系领取奖品。

**如何使用**
1. 将本项目上传到你的 GitHub 仓库（如：allenliemail522-hue/telegram-lottery-wheel）。
2. 在 Vercel 控制台选择「Continue with GitHub」，导入该仓库并部署。
3. 部署完成后会得到一个 URL，使用该 URL 生成二维码即可。

**文件说明**
- index.html: 抽奖页面，静态单文件即可部署。
